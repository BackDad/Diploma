document.addEventListener("DOMContentLoaded", function() {
    var upcomingLessons = document.querySelectorAll(".upcoming-lesson");
    var delay = 2000; // Задержка между уведомлениями в миллисекундах (2 секунды в данном случае)

    upcomingLessons.forEach(function(lessonElement, index) {
        var studentName = lessonElement.getAttribute("data-student-name");
        var lessonTime = lessonElement.getAttribute("data-lesson-time");
        var lessonDate = lessonElement.getAttribute("data-lesson-date");

        var upcomingLesson = {
            studentName: studentName,
            lessonTime: lessonTime,
            lessonDate: lessonDate
        };

        // Задержка перед созданием уведомления
        setTimeout(function() {
            // Проверяем, если есть наступающее занятие
            if (upcomingLesson) {
                // Создаем сообщение для всплывающего окна
                var message = 'У вас ближайшее занятие с ' + upcomingLesson.studentName +
                              ' в ' + upcomingLesson.lessonTime +
                              ' ' + upcomingLesson.lessonDate;

                // Используем Noty для вывода уведомления
                new Noty({
                    layout: 'bottomLeft',
                    text: message,
                    type: 'alert',
                    theme: 'bootstrap-v4',
                    timeout: 5000
                }).show();
            }
        }, index * delay); // Увеличиваем задержку для каждого уведомления
    });
});
