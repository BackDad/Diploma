
    var student_names = {{ student_names|safe }};
    var total_payments = {{ total_payments|safe }};
    // Теперь вы можете использовать эти переменные для построения графика с помощью Chart.js
    var ctx1 = document.getElementById('myChart').getContext('2d');
    var paymentsChart = new Chart(ctx1, {
        type: 'bar',
        data: {
            labels: student_names,
            datasets: [{
                label: 'Оплата',
                data: total_payments,
                backgroundColor: 'rgba(75, 192, 192, 0.9)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });