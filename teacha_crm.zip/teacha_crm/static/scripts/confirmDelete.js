   // Получаем ссылку на элемент "Удалить"
    var deleteLink = document.getElementById("delete-link");

    // Добавляем обработчик события на клик по ссылке "Удалить"
    deleteLink.addEventListener("click", function (e) {
        e.preventDefault(); // Предотвращаем переход по ссылке

        // Отображаем всплывающее окно с подтверждением удаления
        if (confirm("Вы уверены, что хотите удалить эту запись?")) {
            // Если пользователь подтвердил удаление, переходим по ссылке
            window.location.href = deleteLink.href;
        }
    });