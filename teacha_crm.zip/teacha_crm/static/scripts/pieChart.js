
document.addEventListener("DOMContentLoaded", function() {
    var chartElement = document.getElementById('myChart');
    var studentNames = JSON.parse(chartElement.getAttribute('data-student-names'));
    var totalPayments = JSON.parse(chartElement.getAttribute('data-total-payments'));

    // Теперь вы можете использовать переменные studentNames и totalPayments в JavaScript-коде.
    var ctx = chartElement.getContext('2d');
    var paymentsChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: studentNames,
            datasets: [{
                label: 'Оплата',
                data: totalPayments,
                backgroundColor: 'rgba(75, 192, 192, 0.9)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
});
