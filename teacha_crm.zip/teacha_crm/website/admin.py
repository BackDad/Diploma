from django.contrib import admin
from .models import Student, Lesson
admin.site.register(Student)
admin.site.register(Lesson)
# Register your models here.
