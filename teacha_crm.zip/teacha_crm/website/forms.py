from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django import forms
from .models import Student, Lesson


class SignUpForm(UserCreationForm):
    email = forms.EmailField(label="",
                             widget=forms.TextInput(
                                 attrs={'class': 'form-control', 'placeholder': "Электронная почта"}), )
    first_name = forms.CharField(label="", max_length=100,
                                 widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ваше имя'}))
    last_name = forms.CharField(label="", max_length=100,
                                widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ваша фамилия'}))

    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'password1', 'password2',)

    def __init__(self, *args, **kwargs):
        super(SignUpForm, self).__init__(*args, **kwargs)

        self.fields['username'].widget.attrs['class'] = 'form-control'
        self.fields['username'].widget.attrs['placeholder'] = 'Имя пользователя'
        self.fields['username'].label = ''
        self.fields['username'].help_text = '<span class="form-text text-muted"><small>Требуемый. 150 символов или ' \
                                            'меньше. Только буквы, цифры и @/./+/-/_.</small></span>'

        self.fields['password1'].widget.attrs['class'] = 'form-control'
        self.fields['password1'].widget.attrs['placeholder'] = 'Пароль'
        self.fields['password1'].label = ''
        self.fields['password1'].help_text = '<ul class="form-text text-muted small">' \
                                             '<li>Ваш пароль не должен быть слишком похож на другую вашу личную информацию.</li>' \
                                             '<li>Ваш пароль должен содержать не менее 8 символов.</li>' \
                                             '<li>Ваш пароль не может быть часто используемым паролем.</li>' \
                                             '<li>Ваш пароль не может быть полностью цифровым.</li></ul>'

        self.fields['password2'].widget.attrs['class'] = 'form-control'
        self.fields['password2'].widget.attrs['placeholder'] = 'Подтвердите пароль'
        self.fields['password2'].label = ''
        self.fields[
            'password2'].help_text = '<span class="form-text text-muted"><small>Повторите ввод пароля</small></span>'


class Add_record(forms.ModelForm):
    first_name = forms.CharField(required=True,
                                 widget=forms.widgets.TextInput(attrs={"placeholder": "Имя", "class": "form-control"}),
                                 label="")
    last_name = forms.CharField(required=True, widget=forms.widgets.TextInput(
        attrs={"placeholder": "Фамилия", "class": "form-control"}), label="")
    cost = forms.CharField(required=True,
                           widget=forms.widgets.TextInput(attrs={"placeholder": "Стоимость", "class": "form-control"}),
                           label="")
    phone = forms.CharField(required=True,
                            widget=forms.widgets.TextInput(attrs={"placeholder": "Телефон", "class": "form-control"}),
                            label="")
    target = forms.CharField(required=True,
                             widget=forms.widgets.TextInput(
                                 attrs={"placeholder": "Цель занятий", "class": "form-control"}), label="")
    first_day = forms.CharField(required=True,
                                widget=forms.widgets.TextInput(
                                    attrs={"placeholder": "Первый день занятий", "class": "form-control"}), label="")
    first_day_time = forms.CharField(required=True,
                                     widget=forms.widgets.TextInput(
                                         attrs={"placeholder": "Время первого дня", "class": "form-control"}), label="")
    second_day = forms.CharField(required=True,
                                 widget=forms.widgets.TextInput(
                                     attrs={"placeholder": "Второй день занятий", "class": "form-control"}), label="")

    second_day_time = forms.CharField(required=True,
                                      widget=forms.widgets.TextInput(
                                          attrs={"placeholder": "Время второго дня занятий", "class": "form-control"}),
                                      label="")

    class Meta:
        model = Student
        exclude = ("user",)


class Show_lessons(forms.ModelForm):
    def __init__(self, user, *args, **kwargs):
        super(Show_lessons, self).__init__(*args, **kwargs)

        # Добавляем первый элемент в список выбора
        self.fields['student'].empty_label = "Выберите студента"
        self.fields['student'].queryset = Student.objects.filter(user=user)

    lesson_date = forms.DateField(required=True,
                                  widget=forms.widgets.DateInput(
                                      attrs={"placeholder": "Дата занятия", "class": "form-control"}),
                                  label="")
    lesson_duration = forms.TimeField(required=True,
                                      widget=forms.widgets.TimeInput(
                                          attrs={"placeholder": "Длительность", "class": "form-control"}),
                                      label="")
    lesson_topic = forms.CharField(required=True,
                                   widget=forms.widgets.TextInput(
                                       attrs={"placeholder": "Тема занятия", "class": "form-control"}),
                                   label="")

    payment = forms.DecimalField(required=True,
                                 widget=forms.widgets.NumberInput(
                                     attrs={"placeholder": "Стоимость", "class": "form-control"}),
                                 label="")
    payment_bool = forms.BooleanField(
        required=False,  # Поле необязательное
        widget=forms.CheckboxInput(attrs={"class": "checkbox-class"}),  # Устанавливаем класс для стилизации
        label="Оплата   "
    )
    student = forms.ModelChoiceField(
        queryset=Student.objects.none(),
        widget=forms.Select(attrs={'placeholder': "Выбор учащегося", "class": "form-control"}),
        label=""
    )

    next_lesson_comment = forms.CharField(required=True,
                                          widget=forms.widgets.TextInput(
                                              attrs={"placeholder": "Комментарий к следующему занятию",
                                                     "class": "form-control"}),
                                          label="")

    class Meta:
        model = Lesson  # Укажите модель, с которой связана эта форма
        exclude = ("user",)


class EditForm(UserCreationForm):
    email = forms.EmailField(label="",
                             widget=forms.TextInput(
                                 attrs={'class': 'form-control', 'placeholder': "Электронная почта"}), )
    first_name = forms.CharField(label="", max_length=100,
                                 widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ваше имя'}))
    last_name = forms.CharField(label="", max_length=100,
                                widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ваша фамилия'}))

    class Meta:
        model = User
        fields = ('first_name', 'last_name', 'email', 'password1', 'password2',)

    def __init__(self, *args, **kwargs):
        super(EditForm, self).__init__(*args, **kwargs)

        self.fields['password1'].widget.attrs['class'] = 'form-control'
        self.fields['password1'].widget.attrs['placeholder'] = 'Пароль'
        self.fields['password1'].label = ''
        self.fields['password1'].help_text = '<ul class="form-text text-muted small">' \
                                             '<li>Ваш пароль не должен быть слишком похож на другую вашу личную информацию.</li>' \
                                             '<li>Ваш пароль должен содержать не менее 8 символов.</li>' \
                                             '<li>Ваш пароль не может быть часто используемым паролем.</li>' \
                                             '<li>Ваш пароль не может быть полностью цифровым.</li></ul>'

        self.fields['password2'].widget.attrs['class'] = 'form-control'
        self.fields['password2'].widget.attrs['placeholder'] = 'Подтвердите пароль'
        self.fields['password2'].label = ''
        self.fields[
            'password2'].help_text = '<span class="form-text text-muted"><small>Повторите ввод пароля</small></span>'
