from django.db import models
from django.contrib.auth.models import User


# База данных по студентам
class Student(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, default=None)
    created_at = models.DateTimeField(auto_now=True)
    first_name = models.CharField(max_length=50, default="default title")
    last_name = models.CharField(max_length=50, default="default title")
    phone = models.CharField(max_length=12, default="default title")
    cost = models.CharField(max_length=100, default="default title")
    target = models.CharField(max_length=50, default="default title")
    first_day = models.CharField(max_length=50, default="default title")
    first_day_time = models.CharField(max_length=50, default="default title")
    second_day = models.CharField(max_length=50, default="default title")
    second_day_time = models.CharField(max_length=50, default="default title")

    objects = models.Manager()

    def __str__(self):
        return f"{self.first_name} {self.last_name}"


# База данных по урокам студентов
class Lesson(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, default=None)
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    lesson_date = models.DateField()
    lesson_duration = models.CharField(max_length=50, default="default title")
    lesson_topic = models.CharField(max_length=100, default="default title")
    payment = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    payment_bool = models.BooleanField(default=False)
    next_lesson_comment = models.CharField(max_length=200, default=None)

    objects = models.Manager()

    def __str__(self):
        return f"Lesson for {self.student.first_name} {self.student.last_name} on {self.lesson_date}"


# Модель для календаря
class Event(models.Model):
    title = models.CharField(max_length=255)
    start = models.DateField()
    end = models.DateField()
    objects = models.Manager()

    def __str__(self):
        return self.title
