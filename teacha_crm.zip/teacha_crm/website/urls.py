from django.urls import path
from django.contrib.auth import views as auth_views
from . import views
from .views_my.profile import profile_view
from .views_my.lesson import lesson_view
from .views_my.calendar import calendar_view
from .views_my.statistic.get_stat import get_stat
from .views_my.student import student_view
from .views_my.main import main_view

urlpatterns = [
    path('home/', main_view.home, name='home'),
    path('', main_view.login_user, name='login'),
    path('logout/', main_view.logout_user, name='logout'),
    path('register/', main_view.register, name='register'),
    path('record/<int:pk>', student_view.record_student, name='record'),
    path('delete_record/<int:pk>', student_view.delete_student, name='delete_record'),
    path('add_record/', student_view.add_student, name='add_record'),
    path('update_record/<int:pk>', student_view.update_student, name='update_record'),
    path('calendar/', calendar_view.calendar, name='calendar'),
    path('add_event', calendar_view.all_events, name='add_event'),
    path('update', calendar_view.update, name='update'),
    path('remove', calendar_view.remove, name='remove'),
    path('all_events', calendar_view.all_events, name='all_events'),
    path('profile/', profile_view.profile_view, name='profile'),
    path('edit_profile/', profile_view.edit_profile_view, name='edit_profile'),
    path('delete_profile/', profile_view.delete_profile, name='delete_profile'),
    path('statistic/', get_stat, name='statistic'),
    path('add_lessons/', lesson_view.add_lessons, name='add_lessons'),
    path('record_lesson/<int:lesson_id>', lesson_view.lesson_record, name='lesson_record'),
    path('delete_lesson/<int:lesson_id>/', lesson_view.delete_lesson, name='delete_lesson'),

    path('password_reset/', auth_views.PasswordResetView.as_view(), name='password_reset'),
    path('password_reset/done/', auth_views.PasswordResetDoneView.as_view(), name='password_reset_done'),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('reset/done/', auth_views.PasswordResetCompleteView.as_view(), name='password_reset_complete'),
    path('history/', main_view.history, name='history'),
    path('dashboard/', main_view.showDashboard, name='index'),

]

