"""Module"""
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from ...models import Event
from django.http import JsonResponse


# -----КАЛЕНДАРЬ--------------#

# Create your views here.
def calendar(request):
    """Function"""
    if request.user.is_authenticated:
        all_event = Event.objects.all()
        context = {
            "events": all_event,
        }
        return render(request, 'lesson/calendar.html', context)
    else:
        messages.success(request, "Вы не зарегистрированы")
        return redirect('home')


# Display all events.
def all_events(request):
    """Function"""
    all_events = Event.objects.all()
    out = []
    for event in all_events:
        out.append({
            'title': event.title,
            'id': event.id,
            'start': event.start.strftime("%m/%d/%Y, %H:%M:%S"),
            'end': event.end.strftime("%m/%d/%Y, %H:%M:%S"), })
    return JsonResponse(out, safe=False)


# Create event.
def add_event(request):
    """Function"""
    start = request.GET.get("start", None)
    end = request.GET.get("end", None)
    title = request.GET.get("title", None)
    event = Event(title=str(title), start=start, end=end)
    event.save()
    data = {}
    return JsonResponse(data)


# Update event.
def update(request):
    """Function"""
    start = request.GET.get("start", None)
    end = request.GET.get("end", None)
    title = request.GET.get("title", None)
    id = request.GET.get("id", None)
    event = Event.objects.get(id=id)
    event.start = start
    event.end = end
    event.title = title
    event.save()
    data = {}
    return JsonResponse(data)


# Remove event.
def remove(request):
    """Function"""
    id = request.GET.get("id", None)
    event = Event.objects.get(id=id)
    event.delete()
    data = {}
    return JsonResponse(data)
