"""Module"""
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from ...forms import Show_lessons
from ...models import Lesson


# Функция добавления пройденного урока
@login_required
def add_lessons(request):
    """Function"""
    forms = Show_lessons(user=request.user, data=request.POST or None)
    if request.method == "POST":
        if forms.is_valid():
            add_lesson = forms.save(commit=False)
            add_lesson.user = request.user
            forms.save()
            messages.success(request, "Успешно")
            return redirect('home')
    return render(request, 'lesson/add_lessons.html', {'form': forms})


# Функция обновления записи урока
@login_required
def lesson_record(request, lesson_id):
    """Function"""
    lesson = get_object_or_404(Lesson, pk=lesson_id)
    # Если запрос POST, это означает, что пользователь отправил данные для редактирования урока
    if request.method == 'POST':
        forms = Show_lessons(user=request.user, data=request.POST, instance=lesson)
        if forms.is_valid():
            forms.save()
            messages.success(request, "Ваш урок был успешно редактирован.")
            return redirect('lesson_record', lesson_id=lesson_id)
    forms = Show_lessons(user=request.user, instance=lesson)
    return render(request, 'lesson/lesson_record.html', {'lesson': lesson, 'form': forms})


# Функция удаления урока

@login_required
def delete_lesson(request, lesson_id):
    """Function"""
    lesson = get_object_or_404(Lesson, pk=lesson_id, user=request.user)
    if request.method == 'POST':
        lesson.delete()
        messages.success(request, "Урок успешно удален")
        return redirect('home')
    return render(request, 'lesson/confirm_delete_lesson.html', {'lesson': lesson})
