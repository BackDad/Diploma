"""MOdule """
from calendar import monthrange
from datetime import datetime, date
import pytz
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Sum
from ...forms import SignUpForm
from ...models import Student, Lesson

day_translation = {
    'Monday': 'Понедельник',
    'Tuesday': 'Вторник',
    'Wednesday': 'Среда',
    'Thursday': 'Четверг',
    'Friday': 'Пятница',
    'Saturday': 'Суббота',
    'Sunday': 'Воскресенье',
}

tz = pytz.timezone('Europe/Moscow')


@login_required
def home(request):
    """Function"""
    current_user = request.user
    records = Student.objects.filter(user=current_user.id)
    # datetime.now().strftime('%A') = datetime.now().strftime('%A')  # Получить текущий день недели
    current_day_russian = day_translation.get(datetime.now().strftime('%A'),
                                              datetime.now().strftime('%A'))
    records_week = records.filter(first_day=current_day_russian) | records.filter \
        (second_day=current_day_russian)
    current_time = datetime.now(tz)  # Текущее время
    total_payment = 0.00  # Устанавливаем начальное значение total_payment
    if request.user.is_authenticated:
        total_payment = Lesson.objects.filter(user=current_user,
                                              lesson_date__gte=date(date.today().year,
                                                                    date.today().month, 1),
                                              lesson_date__lt=date(date.today().year,
                                                                   date.today().month,
                                                                   monthrange(date.today().year,
                                                                              date.today().month)[1])).aggregate(
            total=Sum('payment'))['total'] or 0.00
    #
    page = request.GET.get('page', 1)
    records_per_page = 4  # Количество записей на странице
    if int(page) < 1:
        page = 1
    paginator = Paginator(records, records_per_page)
    try:
        page_records = paginator.page(page)
    except PageNotAnInteger:
        page_records = paginator.page(1)
    except EmptyPage:
        page_records = paginator.page(paginator.num_pages)

    context = {
        'current_time': current_time,
        'records': page_records,
        'current_day': current_day_russian,
        'records_week': records_week,
        'total_payment': total_payment,
    }
    return render(request, 'main/home.html', context)


def login_user(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, f"Успешная авторизация, {request.user.first_name}"
                                      f" {request.user.last_name}!")
            return redirect('index')
        messages.success(request, "Ошибка, попытайтесь вновь")
        return redirect('login')
    return render(request, 'main/login.html')


def logout_user(request):
    """Function"""
    if request.user.is_authenticated:
        username = f"{request.user.first_name} {request.user.last_name}"
        logout(request)
        messages.success(request, f"{username}, Вы вышли из системы, всего хорошего!")
    return redirect('home')


def register(request):
    """Function"""
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            # Авторизация и вход
            username = form.cleaned_data['username']
            password = form.cleaned_data['password1']
            user = authenticate(username=username, password=password)
            login(request, user)
            messages.success(request,
                             f"{username} - Вы успешно зарегистрировались, добро пожаловать")
            return redirect('home')
    else:
        form = SignUpForm()
        return render(request, 'profile/register.html', {'form': form})
    return render(request, 'profile/register.html', {'form': form})


@login_required
def history(request):
    """Function"""
    current_user = request.user
    all_lessons = Lesson.objects.filter(user=current_user)
    lessons_by_month = {}  # Создаем пустой словарь
    for lesson in all_lessons:
        # Используем месяц и год из даты урока для создания ключа
        month = lesson.lesson_date.strftime("%B %Y")
        if month in lessons_by_month:
            lessons_by_month[month].append(lesson)
        else:
            lessons_by_month[month] = [lesson]
    context = {
        'lessons_by_month': lessons_by_month,
    }
    return render(request, 'main/history.html', context)


def showDashboard(request):
    """Function"""
    current_user = request.user
    records = Student.objects.filter(user=current_user.id)
    current_day_russian = day_translation.get(datetime.now().strftime('%A'),
                                              datetime.now().strftime('%A'))
    records_week = records.filter(first_day=current_day_russian) | records.filter \
        (second_day=current_day_russian)
    current_time = datetime.now(tz)  # Текущее время
    total_payment = 0.00  # Устанавливаем начальное значение total_payment
    if request.user.is_authenticated:
        total_payment = Lesson.objects.filter(user=current_user,
                                              lesson_date__gte=date(date.today().year,
                                                                    date.today().month, 1),
                                              lesson_date__lt=date(date.today().year,
                                                                   date.today().month,
                                                                   monthrange(date.today().year,
                                                                              date.today().month)[1])).aggregate(
            total=Sum('payment'))['total'] or 0.00
    total_student_records = Student.objects.filter(user=current_user).count()
    total_lesson_records = Lesson.objects.filter(user=current_user).count()
    total_duration = Lesson.objects.filter(user=current_user).aggregate(Sum('lesson_duration'))
    total_hours = total_duration['lesson_duration__sum'] or 0

    context = {
        'current_time': current_time,
        'records': records,
        'current_day': current_day_russian,
        'records_week': records_week,
        'total_payment': total_payment,
        'total_student_records': total_student_records,
        'total_lesson_records': total_lesson_records,
        'total_hours': total_hours,
    }
    return render(request, 'main/dashboard.html', context)
