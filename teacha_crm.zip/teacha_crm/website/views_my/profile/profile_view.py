"""Module description"""
from datetime import date
from calendar import monthrange
from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate
from django.contrib import messages
from ...models import Lesson
from ...forms import EditForm


@login_required
def profile_view(request):
    """Function"""
    year = date.today().year
    month = date.today().month
    first_day = date(year, month, 1)
    last_day = date(year, month, monthrange(year, month)[1])
    user = request.user  # Получаем текущего пользователя
    total_payment = Lesson.objects.filter(user=user,
                                          lesson_date__gte=first_day,
                                          lesson_date__lt=last_day
                                          ).aggregate(total=Sum('payment'))['total'] or 0.00
    context = {
        'user': user,
        'total_payment': total_payment,
    }
    return render(request, 'profile/profile.html', context)


@login_required
def delete_profile(request):
    """Function"""
    if request.method == 'POST':
        # Получите введенный пользователем пароль
        password = request.POST['password']
        # Проверьте пароль пользователя
        user = authenticate(username=request.user.username, password=password)
        if user is not None:
            # Если пароль верен, удалите профиль пользователя
            user.delete()
            messages.success(request, "Ваш профиль был успешно удален.")
            return redirect('home')  # Замените 'home' на URL вашей главной страницы
        else:
            # Если пароль неверен, выведите сообщение об ошибке
            messages.error(request, "Неверный пароль. Пожалуйста, попробуйте еще раз.")
            return render(request, 'profile/delete_profile.html')
    return render(request, 'profile/delete_profile.html')


@login_required
def edit_profile_view(request):
    """Function"""
    if request.method == 'POST':
        form = EditForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, "Ваши данные успешно обновлены")
            return redirect('profile')
    else:
        form = EditForm(instance=request.user)
    return render(request, 'profile/edit_profile.html', {'form': form})
