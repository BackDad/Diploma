""" Описание модуля """
from calendar import monthrange
from datetime import date, timedelta
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.db.models import Sum
from ...models import Student, Lesson


day_translation = {
    'Monday': 'Понедельник',
    'Tuesday': 'Вторник',
    'Wednesday': 'Среда',
    'Thursday': 'Четверг',
    'Friday': 'Пятница',
    'Saturday': 'Суббота',
    'Sunday': 'Воскресенье',
}


@login_required
def get_stat(request):
    """ Описание функции"""
    user = request.user
    student_payments = Lesson.objects.filter(user=user).values('student__first_name',
                                                               'student__last_name').annotate(
        total_payment=Sum('payment'))
    student_names = [f"{entry['student__first_name']} " \
                     f"{entry['student__last_name']}" for entry in student_payments]
    total_payments = [int(entry['total_payment']) for entry in student_payments]
    # ----Пайчарт для сравнения заработано и сколько осталось
    year = date.today().year
    month = date.today().month
    user = request.user
    students = Student.objects.filter(user=user)
    day_payments = {
        'Понедельник': 0,
        'Вторник': 0,
        'Среда': 0,
        'Четверг': 0,
        'Пятница': 0,
        'Суббота': 0,
        'Воскресенье': 0,
    }
    day_of_week_to_day_in_month = {
        'Понедельник': 1,
        'Вторник': 2,
        'Среда': 3,
        'Четверг': 4,
        'Пятница': 5,
        'Суббота': 6,
        'Воскресенье': 7,
    }
    days_count = {day: 0 for day in range(7)}  # 0 - Понедельник, 1 - Вторник, и т.д.
    # Переберите записи и увеличьте суммы payment для соответствующих дней недели
    for student in students:
        first_day_of_week = student.first_day  # Название дня недели (например, 'Вторник')
        second_day_of_week = student.second_day  # Название дня недели (например, 'Вторник')
        # Получите соответствующее число дня в месяце
        first_day_in_month = day_of_week_to_day_in_month.get(first_day_of_week)
        second_day_in_month = day_of_week_to_day_in_month.get(second_day_of_week)

        if first_day_in_month is not None:
            # Увеличьте сумму payment для этого дня недели
            day_payments[first_day_of_week] += int(student.cost)
            # print(day_payments)
        if second_day_in_month is not None:
            # Увеличьте сумму payment для этого дня недели
            day_payments[second_day_of_week] += int(student.cost)
            # print(day_payments)


        # Перевод словаря с Понедельник Вторник в  0 1 b тд
    new_key = [0, 1, 2, 3, 4, 5, 6]
    day_payments = dict(zip(new_key, list(day_payments.values())))
    # ----------------------------------------------------------------------------
    # Находим первый и последний дни месяца
    first_day = date(year, month, 1)
    last_day = date(year, month, monthrange(year, month)[1])

    # Перебираем все дни в месяце и увеличиваем счетчик соответствующего дня недели
    current_day = first_day
    while current_day <= last_day:
        day_of_week = current_day.weekday()  # 0 - Понедельник, 1 - Вторник, и т.д.
        days_count[day_of_week] += 1
        current_day += timedelta(days=1)
        # Нахождение полной зарплаты за месяц
    cost_per_month = {day: days_count[day] * day_payments[day] for day in days_count}

    # Получить сумму всех занятий за текущий месяц
    total_payment_true = Lesson.objects.filter(user=user,
                                               lesson_date__gte=first_day,
                                               lesson_date__lt=last_day,
                                               payment_bool=True
                                               ).aggregate(total=Sum('payment'))['total'] or 0.00
    total_payment_false = Lesson.objects.filter(user=user,
                                                lesson_date__gte=first_day,
                                                lesson_date__lt=last_day,
                                                payment_bool=False
                                                ).aggregate(total=Sum('payment'))['total'] or 0.00

    context = {
        'student_names': student_names,
        'total_payments': total_payments,
        'goal': (sum(cost_per_month.values()) - int(total_payment_true) - int(total_payment_false)),
        'current': int(total_payment_true),
        'not_paid': int(total_payment_false),
    }
    return render(request, 'profile/statistic.html', context)
