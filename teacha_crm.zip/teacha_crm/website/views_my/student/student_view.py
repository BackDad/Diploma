"""Работа с данными модели Student"""

from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.contrib import messages
from ...forms import Add_record
from ...models import Student, Lesson


@login_required
def add_student(request):
    """Function """
    form = Add_record(request.POST or None)
    if request.method == "POST":
        if form.is_valid():
            add_record = form.save(commit=False)
            add_record.user = request.user
            add_record = form.save()
            messages.success(request, "Успешно")
            return redirect('home')
    return render(request, 'student/add_record.html', {'form': form})


@login_required
def delete_student(request, pk):

    """Function """

    delete_it = Student.objects.get(id=pk)
    delete_it.delete()
    messages.success(request, "Успешно удалено")
    return redirect('home')


@login_required
def update_student(request, pk):
    """Function """
    current_record = Student.objects.get(id=pk)
    form = Add_record(request.POST or None, instance=current_record)
    if form.is_valid():
        form.save()
        messages.success(request, "Успешно обновлено")
        return redirect('home')
    return render(request, 'student/update_record.html', {'form': form})


@login_required
def record_student(request, pk):
    """Function"""
    current_user = request.user
    customer_record = Student.objects.filter(user=current_user, id=pk).first()
    if customer_record:
        student_lessons = Lesson.objects.filter(student=customer_record)
        return render(request, 'student/record.html',
                      {'customer_record': customer_record, 'student_lessons': student_lessons})

    messages.success(request, "Студент не найден или не принадлежит вам.")
    return redirect('home')
